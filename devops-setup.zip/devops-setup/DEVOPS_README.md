# 🚀 Flipkart Auth — Production DevOps Setup

Complete Docker + GitHub Actions deployment guide for React + Node.js + MariaDB.

---

## 📁 Final Folder Structure

```
flipkart-auth/
├── .env                          ← Real secrets (NEVER commit)
├── .env.example                  ← Template (safe to commit)
├── .gitignore
├── docker-compose.yml
├── setup.sql                     ← Optional DB seed
│
├── backend/
│   ├── Dockerfile
│   ├── server.js
│   ├── db.js
│   ├── routes/
│   ├── controllers/
│   └── package.json
│
├── frontend/
│   ├── Dockerfile
│   ├── nginx.conf                ← Nginx config with /api proxy
│   ├── src/
│   └── package.json
│
└── .github/
    └── workflows/
        └── deploy.yml            ← GitHub Actions CI/CD
```

---

## ⚠️ Common Mistakes & Fixes

### 1. DB_HOST=localhost inside Docker ❌
```env
# WRONG — "localhost" inside a container refers to the container itself
DB_HOST=localhost

# CORRECT — use the Docker Compose service name
DB_HOST=db
```

### 2. Frontend calling http://localhost:5000 ❌
The frontend is served from Nginx inside its own container. "localhost:5000" doesn't exist there.
```
# WRONG — AuthContext.js
const API = axios.create({ baseURL: "http://localhost:5000/api/auth" })

# CORRECT — use a relative path; Nginx proxies /api → backend:5000
const API = axios.create({ baseURL: "/api/auth" })
```
Your existing `AuthContext.js` already uses `baseURL: "/api/auth"` ✅  
The `nginx.conf` in this setup proxies that to `http://backend:5000`. ✅

### 3. Frontend package.json proxy field breaks in production ❌
```json
// WRONG — this "proxy" only works for CRA dev server, ignored in Nginx build
"proxy": "http://localhost:5000"
```
Remove or ignore it. The Nginx `proxy_pass` directive handles this in production.

### 4. Backend starts before DB is ready ❌
The `depends_on` with `condition: service_healthy` in docker-compose.yml waits for
MariaDB's healthcheck to pass before starting the backend. ✅

### 5. CORS origin set to localhost ❌
```env
# WRONG
FRONTEND_URL=http://localhost:3000

# CORRECT — set to your EC2 IP or domain
FRONTEND_URL=http://54.123.45.67
```

### 6. Not using .dockerignore ❌
Add a `.dockerignore` to each service to avoid copying `node_modules` into the build context.

---

## 🛠️ Local Development

```bash
# 1. Clone the repo
git clone https://github.com/YOUR_USERNAME/flipkart-auth.git
cd flipkart-auth

# 2. Create .env from template
cp .env.example .env
# Edit .env and fill in your values

# 3. Build and start all services
docker compose up --build

# 4. Visit http://localhost
```

### Useful Commands
```bash
# View logs
docker compose logs -f
docker compose logs -f backend

# Restart a single service
docker compose restart backend

# Stop everything
docker compose down

# Stop and delete volumes (wipes DB data)
docker compose down -v

# Rebuild a single service
docker compose build frontend
docker compose up -d frontend
```

---

## ☁️ EC2 Deployment

### Step 1 — Launch EC2
- AMI: Ubuntu 22.04 LTS
- Type: t3.micro (free tier) or t3.small
- Security Group inbound rules:
  - Port 22  (SSH)    — your IP only
  - Port 80  (HTTP)   — 0.0.0.0/0
  - Port 443 (HTTPS)  — 0.0.0.0/0 (when you add SSL)

### Step 2 — Bootstrap EC2
```bash
# Copy and run the bootstrap script on EC2
scp -i your-key.pem scripts/ec2-bootstrap.sh ubuntu@EC2_IP:~
ssh -i your-key.pem ubuntu@EC2_IP
bash ec2-bootstrap.sh
```

### Step 3 — Add GitHub Secrets
Go to: GitHub repo → Settings → Secrets → Actions → New repository secret

| Secret Name   | Value                                         |
|---------------|-----------------------------------------------|
| EC2_HOST      | Your EC2 public IP (e.g. 54.123.45.67)       |
| EC2_USER      | ubuntu (or ec2-user for Amazon Linux)         |
| EC2_SSH_KEY   | Contents of your .pem file (entire file)      |
| APP_DIR       | /home/ubuntu/app                              |
| ENV_FILE      | Entire contents of your .env file             |

### Step 4 — Push to main
```bash
git add .
git commit -m "Add DevOps setup"
git push origin main
```
GitHub Actions will SSH into EC2, pull the code, and run `docker compose up -d`.

---

## 🔐 Adding HTTPS (Optional but Recommended)

```bash
# On EC2, install Certbot
sudo apt install certbot python3-certbot-nginx -y

# Stop Docker frontend container first
docker compose stop frontend

# Get certificate (replace with your domain)
sudo certbot --nginx -d yourdomain.com

# Then update nginx.conf to listen on 443 and mount the cert path
```

Or use a load balancer (AWS ALB) to terminate SSL — cleaner for production.

---

## 🔄 How It All Fits Together

```
User Browser
     │
     ▼
EC2 Port 80
     │
     ▼
┌─────────────────┐
│   frontend      │  Nginx serves React SPA
│   container     │  Proxies /api/* → backend:5000
└────────┬────────┘
         │ Docker network (app_network)
         ▼
┌─────────────────┐
│   backend       │  Express on port 5000
│   container     │  Reads DB via mysql2
└────────┬────────┘
         │ Docker network (app_network)
         ▼
┌─────────────────┐
│   db            │  MariaDB 11
│   container     │  Data persisted in db_data volume
└─────────────────┘
```
