#!/bin/bash
# scripts/ec2-bootstrap.sh
# Run this ONCE on a fresh EC2 instance (Ubuntu 22.04/24.04) to prepare it.
# Usage: bash ec2-bootstrap.sh

set -e

echo "🔧 Updating system packages..."
sudo apt-get update -y && sudo apt-get upgrade -y

echo "🐳 Installing Docker..."
sudo apt-get install -y ca-certificates curl gnupg
sudo install -m 0755 -d /etc/apt/keyrings
curl -fsSL https://download.docker.com/linux/ubuntu/gpg \
  | sudo gpg --dearmor -o /etc/apt/keyrings/docker.gpg
sudo chmod a+r /etc/apt/keyrings/docker.gpg

echo \
  "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] \
  https://download.docker.com/linux/ubuntu $(. /etc/os-release && echo "$VERSION_CODENAME") stable" \
  | sudo tee /etc/apt/sources.list.d/docker.list > /dev/null

sudo apt-get update -y
sudo apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin

# Allow current user to run Docker without sudo
sudo usermod -aG docker $USER

echo "✅ Docker installed: $(docker --version)"
echo "✅ Docker Compose installed: $(docker compose version)"

echo ""
echo "📂 Cloning your repo..."
# Replace with your actual repo URL
REPO_URL="https://github.com/YOUR_USERNAME/YOUR_REPO.git"
APP_DIR="/home/$USER/app"

git clone "$REPO_URL" "$APP_DIR" || echo "Repo already exists, skipping clone."
cd "$APP_DIR"

echo ""
echo "⚠️  Next steps:"
echo "  1. Copy your .env file: nano $APP_DIR/.env"
echo "  2. Start the app:       cd $APP_DIR && docker compose up -d"
echo ""
echo "✅ EC2 bootstrap complete! Log out and back in for Docker group to apply."
